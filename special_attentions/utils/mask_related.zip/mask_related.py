#####################################################################################################
#                         处理不被64整除
#####################################################################################################
def preprocess_qkv(q, k, v):
    stride = 64  # 降采样16倍
    text_length=226
    q_text=q[:,:,:text_length]
    k_text=k[:,:,:text_length]
    v_text=v[:,:,:text_length]
    frame_length=1350
    frame_num=13
    if(frame_length%stride!=0):
        padding=stride-frame_length%stride
        q_video=rearrange(q[:,:,text_length:],'b h (t s) d-> b h t s d',t=frame_num)
        k_video=rearrange(k[:,:,text_length:],'b h (t s) d-> b h t s d',t=frame_num)
        v_video=rearrange(v[:,:,text_length:],'b h (t s) d-> b h t s d',t=frame_num)
        q_video=torch.nn.functional.pad(q_video,(0,0,0,padding)).view(2,30,-1,64)
        k_video=torch.nn.functional.pad(k_video,(0,0,0,padding)).view(2,30,-1,64)
        v_video=torch.nn.functional.pad(v_video,(0,0,0,padding)).view(2,30,-1,64)
    q_processed = torch.cat((q_video, q_text), dim=-2)
    k_processed = torch.cat((k_video, k_text), dim=-2)
    v_processed = torch.cat((v_video, v_text), dim=-2)
    return q_processed, k_processed, v_processed
def reverse_process_out(out):
    frame_length=1350
    frame_num=13
    text_length=226
    out_text=out[:,:,-text_length:]
    out_video_with_padding=out[:,:,:-text_length].reshape(2,30,frame_num,-1,64)
    out_video=out_video_with_padding[:,:,:,:frame_length].reshape(2,30,-1,64)
    out=torch.cat((out_text,out_video),dim=-2)
    return out
#####################################################################################################
#                         生成注意力掩码 帧间
#####################################################################################################
import torch
from einops import rearrange
from einops import rearrange
def generate_attention_mask_frame_scope(q, k, text_length=226, f=13, 
                           width=45, height=30, sample_num=270,
                           scale_factor=1/8, base_threshold=0.6):
    """
    整合注意力权重生成和诊断的完整流程
    
    Args:
        q (torch.Tensor): 查询张量 [b, h, s, d]
        k (torch.Tensor): 键张量 [b, h, s, d]
        text_length (int): 文本特征长度
        f (int): 视频帧数
        width (int): 图像宽度
        height (int): 图像高度
        sample_num (int): 采样点数
        scale_factor (float): 缩放因子
        base_threshold (float): 基础阈值
    
    Returns:
        torch.Tensor: 最终注意力掩码 [b, h, f, f+1]
    """
    # 第一阶段：生成注意力权重矩阵
    def get_indexs():
        text_idxs = torch.arange(0, text_length)
        img_first_frame_idxs = torch.randint(0, (width*height), (sample_num,)) + text_length
        frame_offsets = torch.arange(f) * (width * height)
        all_idxs = (img_first_frame_idxs.view(1, -1) + frame_offsets.view(-1, 1)).view(-1)
        return torch.cat([text_idxs, all_idxs])

    # 特征索引处理
    indexs_k = get_indexs()
    q = q[:, :, indexs_k, :]
    k = k[:, :, indexs_k, :]

    # 计算注意力矩阵
    out = torch.matmul(q, k.transpose(-2, -1)) * scale_factor
    sample_rate = torch.tensor(sample_num / (width * height))
    composition = torch.log(sample_rate).view(1,1,1,1).to(q.dtype).to(q.device)
    out[:, :, :, :text_length] += composition
    out = torch.softmax(out, dim=-1)

    # 生成图像-文本注意力
    img2text_weight = out[:, :, :, :text_length]
    img2text_map = rearrange(img2text_weight[:, :, text_length:, :], 
                            "b h (pn pl) tl -> b h pn (pl tl)", 
                            pl=sample_num, pn=f).sum(-1, keepdim=True) / sample_num

    # 生成图像-图像注意力
    img2img_map = rearrange(
        rearrange(out[:, :, text_length:, text_length:], 
                 'b h (f1 s1) (f2 s2) -> b h (f1 f2) (s1 s2)',
                 s1=sample_num, s2=sample_num).sum(-1),
        'b h (f1 f2) -> b h f1 f2', f1=f, f2=f) / sample_num

    # 拼接注意力矩阵
    img2all = torch.cat([img2text_map, img2img_map], dim=-1)

    # 第二阶段：注意力诊断
    B, H, F1, F2 = img2all.shape
    sorted_values, sorted_indices = torch.sort(img2all, dim=-1, descending=True)
    cum_sum = torch.cumsum(sorted_values, dim=-1)
    
    # 动态阈值处理
    over_threshold = cum_sum >= base_threshold
    k = torch.argmax(over_threshold.int(), dim=-1)
    
    # 生成初始掩码
    ranks = torch.arange(F2, device=img2all.device).view(1,1,1,F2).expand(B,H,F1,F2)
    selected = ranks <= k.unsqueeze(-1)
    mask = torch.zeros_like(img2all, dtype=torch.bool)
    mask.scatter_(-1, sorted_indices, selected)
    
    # 二次鉴定机制
    mask_mean = mask.float().mean(dim=[-1,-2])  # [B,H]
    condition = mask_mean > 0.75 * base_threshold
    final_mask = torch.where(condition.view(B,H,1,1).expand_as(mask),
                           torch.ones_like(mask),
                           mask.float())

    return final_mask[:,:,:,1:]

####################################################################################################
#                         聚类相关函数，用来提高分块的效率
####################################################################################################
from torch_kmeans import KMeans

class ClusterRearrange_fullq:
    def __init__(self, q, k_num=64, num_iterations=10, random_seed=0):
        """
        Initialize the ClusterRearrange class with a query tensor.

        Args:
            q (torch.Tensor): Input tensor of shape [batch_size, num_heads, seq_len, dim].
            k_percentage (float): Percentage of sequence length to determine number of clusters.
            num_iterations (int): Number of iterations for K-means clustering.
            random_seed (int): Random seed for reproducibility.
        """
        # Store tensor dimensions and parameters
        self.batch_size, self.num_heads, self.seq_len, self.dim = q.shape
        self.num_iterations = num_iterations
        self.random_seed = random_seed
        
        # Calculate number of clusters
        self.k = k_num
        # 查看当前显存使用量（单位：字节）
        # Initialize and train KMeans on q[0]
        self.kmeans = KMeans(n_clusters=self.k, max_iter=self.num_iterations, random_state=self.random_seed,init_method='k-means++')
        # 查看当前显存使用量（单位：字节）
        sequence_train = q[0,:,226:1350+226]  # Shape: [num_heads, seq_len, dim]
        self.kmeans.fit(sequence_train)
        torch.cuda.empty_cache()
        # Get labels and sorted indices for q[0]
        labels_train = self.kmeans.predict(q[0])  # Shape: [num_heads, seq_len]
        self.sorted_indices_train = torch.argsort(labels_train, dim=-1).to(torch.int16)  # Shape: [num_heads, seq_len]
        del self.kmeans  # Delete KMeans model to save memory
        del labels_train
        torch.cuda.empty_cache()
    def rearrange_q(self, q):
        """
        Rearrange the qkv tensor based on clustering of q[0].

        Args:
            q (torch.Tensor): Tensor of shape [batch_size, num_heads, seq_len, dim].

        Returns:
            torch.Tensor: Rearranged tensor of the same shape.
        """
        rearranged_q = torch.zeros_like(q)
        for b in range(self.batch_size):
                # Use sorted indices from q[0] for the first batch
                sorted_indices = self.sorted_indices_train.unsqueeze(-1).expand(self.num_heads, self.seq_len, self.dim).to(torch.int64)
                rearranged_q[b] = torch.gather(q[b], dim=-2, index=sorted_indices)
        return rearranged_q
    
    def recover_q(self, rearranged_q):
        """
        Recover the original qkv tensor from the rearranged tensor.

        Args:
            rearranged_q (torch.Tensor): Rearranged tensor of shape [batch_size, num_heads, seq_len, dim].

        Returns:
            torch.Tensor: Original tensor of the same shape.
        """
        original_q = torch.zeros_like(rearranged_q)
        sorted_indices = self.sorted_indices_train.unsqueeze(-1).expand(self.num_heads, self.seq_len, self.dim).to(torch.int64)
        for b in range(self.batch_size):
                original_q[b] = torch.scatter(original_q[b], dim=-2, index=sorted_indices, src=rearranged_q[b])
        
        return original_q
####################################################################################################
#                          帧内mask生成函数
####################################################################################################
def calc_attn(q, k):
        out = q @ k.transpose(-1, -2) / 8
        out = out - out.max(dim=-1, keepdim=True).values
        out = out.softmax(dim=-1)
        return out
def process_attn(attn):
    # 输入attn的形状: (batch, num_heads, q_len, k_len)
    attn = attn[:1]  # 只处理第一个batch
    batch, num_heads, q_len, k_len = attn.shape

    # 步骤0：使用padding和sum将后两维度变小
    stride = 64  # 降采样64倍
    # 计算需要padding的大小
    pad_q = (stride - q_len % stride) % stride
    pad_k = (stride - k_len % stride) % stride
    # 对attn进行padding
    attn_padded = torch.nn.functional.pad(attn, (0, pad_k, 0, pad_q))  # (batch, num_heads, q_len + pad_q, k_len + pad_k)
    # 使用rearrange和sum进行降采样
    attn_reduced = rearrange(
        attn_padded,
        "b h (q1 s1) (k1 s2) -> b h q1 k1 (s1 s2)",
        s1=stride,
        s2=stride,
    ).sum(dim=-1)  # (batch, num_heads, q_len_reduced, k_len_reduced)
    attn_reduced[:, :, -1, :] = attn_reduced[:, :, -1, :] * stride / (stride - pad_q)  # 校正边缘效应
    attn_reduced[:, :, :, -1] = attn_reduced[:, :, :, -1] * stride / (stride - pad_k)  # 校正边缘效应
    q_len_reduced, k_len_reduced = attn_reduced.shape[-2:]

    # 步骤1：将后两维度展平
    attn_flattened = attn_reduced.reshape(batch, num_heads, -1)  # (batch, num_heads, q_len_reduced * k_len_reduced)

    # 步骤2：对每个head的注意力值进行排序
    attn_sorted, indices = torch.sort(attn_flattened, dim=-1, descending=True)  # 对每个head的值进行排序

    # 步骤3：计算累积和
    cum_sum = torch.cumsum(attn_sorted, dim=-1)  # 计算排序后的累积和
    total_energy = cum_sum[:, :, -1].unsqueeze(-1)  # 总能量（即全部和）

    # 步骤4：确定保留80%的注意力值
    threshold = total_energy * 0.8  # 目标阈值（总能量的80%）
    mask = cum_sum <= threshold  # 找到累积和小于等于阈值的位置
    # 处理所有元素都小于阈值的情况，确保至少保留一个元素
    mask[:, :, -1] = True  # 强制保留最后一个元素

    # 步骤5：将排序后的位置映射回原始索引
    final_mask = torch.zeros_like(attn_flattened, dtype=torch.bool)
    final_mask.scatter_(-1, indices, mask)  # 将保留的位置设置为True
    final_mask = final_mask.view(batch, num_heads, q_len_reduced, k_len_reduced)  # 恢复形状
    return final_mask
def get_inner_frame_mask(q,k):
    attn=calc_attn(q[:,:,226:226+1350],k[:,:,226:226+1350])
    mask=process_attn(attn)
    return mask
####################################################################################################
#                         生成视频mask
####################################################################################################
def get_block_mask(inner_frame_mask,frame_mask):
    inner_mask_float = inner_frame_mask.float()      # 转换为 float32
    # 修正后的爱因斯坦方程
    video_mask = torch.einsum('bhac,bhde->bhadce', frame_mask, inner_mask_float)
    video_mask = video_mask.reshape(2, 30, 13*22, 13*22)  # 显式合并维度
    padding=4
    video_mask = torch.nn.functional.pad(video_mask, (0, padding, 0, padding),value=1)  # 填充
    return video_mask
####################################################################################################
